from courses.models import Course, Material, Teacher


def run():
    # This is where the faker must run
    pass
